<template>
  <Landing />
</template>

<script>
import Landing from "@/components/offline_help/index.vue";
console.log(process.env);
export default {
  components: {
    Landing,
  },
};
</script>
