<template>
  <CreateRoom />
</template>

<script>
import CreateRoom from "../../components/room/createRoom.vue";

export default {
  components: {
    CreateRoom,
  },
};
</script>
