<template>
  <div class="manager-page1">
    <Manager />
  </div>
</template>

<script>
import Manager from "../../components/manager/manager.vue";

export default {
  components: {
    Manager,
  },
};
</script>
