<template>
  <DoctorSignUp />
</template>

<script>
import DoctorSignUp from "../../components/Authentication/doctorsignup.vue";

export default {
  components: {
    DoctorSignUp,
  },
};
</script>
