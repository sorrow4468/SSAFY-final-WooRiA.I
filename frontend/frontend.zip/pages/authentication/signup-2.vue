<template>
  <SignUpClassic />
</template>

<script>
import SignUpClassic from "../../components/Authentication/signup-2.vue";

export default {
  components: {
    SignUpClassic,
  },
};
</script>
