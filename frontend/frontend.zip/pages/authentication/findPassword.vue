<template>
  <FindPassword />
</template>

<script>
import FindPassword from "../../components/Authentication/findPassword.vue";

export default {
  components: {
    FindPassword,
  },
};
</script>
