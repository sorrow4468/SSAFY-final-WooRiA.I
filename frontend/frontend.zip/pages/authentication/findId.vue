<template>
  <FindId />
</template>

<script>
import FindId from "../../components/Authentication/findId.vue";

export default {
  components: {
    FindId,
  },
};
</script>
