<template>
  <SignUp />
</template>

<script>
import SignUp from "../../components/Authentication/signup.vue";

export default {
  components: {
    SignUp,
  },
};
</script>
