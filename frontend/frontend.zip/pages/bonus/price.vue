<template>
  <BonusPrice />
</template>

<script>
import BonusPrice from "../../components/bonus_page/price/index.vue";

export default {
  components: {
    BonusPrice,
  },
};
</script>
