<template>
  <Landing />
</template>

<script>
import Landing from "../components/landing-page/index.vue";
console.log(process.env);
export default {
  components: {
    Landing,
  },
};
</script>
