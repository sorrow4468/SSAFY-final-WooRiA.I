<template>
  <PageNotFound />
</template>

<script>
import PageNotFound from "../../components/pagenotfound/index.vue";

export default {
  components: {
    PageNotFound,
  },
};
</script>
