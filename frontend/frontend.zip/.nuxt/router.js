import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _91b4ca94 = () => interopDefault(import('..\\pages\\pagenotfound\\index.vue' /* webpackChunkName: "pages/pagenotfound/index" */))
const _2497c2c6 = () => interopDefault(import('..\\pages\\authentication\\doctorsignup.vue' /* webpackChunkName: "pages/authentication/doctorsignup" */))
const _1ae44e9a = () => interopDefault(import('..\\pages\\authentication\\login.vue' /* webpackChunkName: "pages/authentication/login" */))
const _fe312dd0 = () => interopDefault(import('..\\pages\\authentication\\login-2.vue' /* webpackChunkName: "pages/authentication/login-2" */))
const _14d02a61 = () => interopDefault(import('..\\pages\\authentication\\mypage.vue' /* webpackChunkName: "pages/authentication/mypage" */))
const _a8f1aa84 = () => interopDefault(import('..\\pages\\authentication\\signup.vue' /* webpackChunkName: "pages/authentication/signup" */))
const _3e57373a = () => interopDefault(import('..\\pages\\authentication\\signup-2.vue' /* webpackChunkName: "pages/authentication/signup-2" */))
const _08b879ca = () => interopDefault(import('..\\pages\\blogs\\blog_details\\index.vue' /* webpackChunkName: "pages/blogs/blog_details/index" */))
const _28522072 = () => interopDefault(import('..\\pages\\blogs\\blog_left-sidebar\\index.vue' /* webpackChunkName: "pages/blogs/blog_left-sidebar/index" */))
const _c82b1810 = () => interopDefault(import('..\\pages\\blogs\\blog_no-sidebar\\index.vue' /* webpackChunkName: "pages/blogs/blog_no-sidebar/index" */))
const _75355a41 = () => interopDefault(import('..\\pages\\blogs\\blog_right-sidebar\\index.vue' /* webpackChunkName: "pages/blogs/blog_right-sidebar/index" */))
const _f7c7e188 = () => interopDefault(import('..\\pages\\bonus\\about.vue' /* webpackChunkName: "pages/bonus/about" */))
const _1a624379 = () => interopDefault(import('..\\pages\\bonus\\chat.vue' /* webpackChunkName: "pages/bonus/chat" */))
const _c076c5d0 = () => interopDefault(import('..\\pages\\bonus\\elements.vue' /* webpackChunkName: "pages/bonus/elements" */))
const _29028405 = () => interopDefault(import('..\\pages\\bonus\\faq.vue' /* webpackChunkName: "pages/bonus/faq" */))
const _55415ef8 = () => interopDefault(import('..\\pages\\bonus\\price.vue' /* webpackChunkName: "pages/bonus/price" */))
const _411c3b4e = () => interopDefault(import('..\\pages\\manager\\manager.vue' /* webpackChunkName: "pages/manager/manager" */))
const _2bae6a15 = () => interopDefault(import('..\\pages\\oauth\\Redirect.vue' /* webpackChunkName: "pages/oauth/Redirect" */))
const _70ec6926 = () => interopDefault(import('..\\pages\\offline\\help.vue' /* webpackChunkName: "pages/offline/help" */))
const _d4aa8480 = () => interopDefault(import('..\\pages\\offline\\room.vue' /* webpackChunkName: "pages/offline/room" */))
const _5078009c = () => interopDefault(import('..\\pages\\online\\room.vue' /* webpackChunkName: "pages/online/room" */))
const _4ef83508 = () => interopDefault(import('..\\pages\\reserve\\applyReservation.vue' /* webpackChunkName: "pages/reserve/applyReservation" */))
const _c78646bc = () => interopDefault(import('..\\pages\\reserve\\checkReservation.vue' /* webpackChunkName: "pages/reserve/checkReservation" */))
const _8e45f776 = () => interopDefault(import('..\\pages\\room\\createRoom copy.vue' /* webpackChunkName: "pages/room/createRoom copy" */))
const _7012fad8 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'hash',
  base: '/chitchat/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/pagenotfound",
    component: _91b4ca94,
    name: "pagenotfound"
  }, {
    path: "/authentication/doctorsignup",
    component: _2497c2c6,
    name: "authentication-doctorsignup"
  }, {
    path: "/authentication/login",
    component: _1ae44e9a,
    name: "authentication-login"
  }, {
    path: "/authentication/login-2",
    component: _fe312dd0,
    name: "authentication-login-2"
  }, {
    path: "/authentication/mypage",
    component: _14d02a61,
    name: "authentication-mypage"
  }, {
    path: "/authentication/signup",
    component: _a8f1aa84,
    name: "authentication-signup"
  }, {
    path: "/authentication/signup-2",
    component: _3e57373a,
    name: "authentication-signup-2"
  }, {
    path: "/blogs/blog_details",
    component: _08b879ca,
    name: "blogs-blog_details"
  }, {
    path: "/blogs/blog_left-sidebar",
    component: _28522072,
    name: "blogs-blog_left-sidebar"
  }, {
    path: "/blogs/blog_no-sidebar",
    component: _c82b1810,
    name: "blogs-blog_no-sidebar"
  }, {
    path: "/blogs/blog_right-sidebar",
    component: _75355a41,
    name: "blogs-blog_right-sidebar"
  }, {
    path: "/bonus/about",
    component: _f7c7e188,
    name: "bonus-about"
  }, {
    path: "/bonus/chat",
    component: _1a624379,
    name: "bonus-chat"
  }, {
    path: "/bonus/elements",
    component: _c076c5d0,
    name: "bonus-elements"
  }, {
    path: "/bonus/faq",
    component: _29028405,
    name: "bonus-faq"
  }, {
    path: "/bonus/price",
    component: _55415ef8,
    name: "bonus-price"
  }, {
    path: "/manager/manager",
    component: _411c3b4e,
    name: "manager-manager"
  }, {
    path: "/oauth/Redirect",
    component: _2bae6a15,
    name: "oauth-Redirect"
  }, {
    path: "/offline/help",
    component: _70ec6926,
    name: "offline-help"
  }, {
    path: "/offline/room",
    component: _d4aa8480,
    name: "offline-room"
  }, {
    path: "/online/room",
    component: _5078009c,
    name: "online-room"
  }, {
    path: "/reserve/applyReservation",
    component: _4ef83508,
    name: "reserve-applyReservation"
  }, {
    path: "/reserve/checkReservation",
    component: _c78646bc,
    name: "reserve-checkReservation"
  }, {
    path: "/room/createRoom%20copy",
    component: _8e45f776,
    name: "room-createRoom copy"
  }, {
    path: "/",
    component: _7012fad8,
    name: "index"
  }, {
    path: "*",
    component: _91b4ca94
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
