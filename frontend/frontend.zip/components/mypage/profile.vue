<template>
  <div>
    <h3>프로필 사진</h3>
    <img src="https://picsum.photos/125/125/?image=58" alt="">
    <h3>이름</h3>
    <h3>상태메시지</h3>
    <h3>이메일</h3>
    <h3>병원명</h3>
    <h3>진료과</h3>
    <h3>약력</h3>
  </div>
</template>

<script>
export default {
  
}
</script>

<style>

</style>