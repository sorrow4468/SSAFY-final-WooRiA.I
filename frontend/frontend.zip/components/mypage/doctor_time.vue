<template>
  <div>
    <h3>의사 자격증</h3>
    <img src="https://picsum.photos/125/125/?image=58" alt="">
    <h2>진료가능시간</h2>
    <h3>월요일</h3>
    <h3>화요일</h3>
    <h3>수요일</h3>
    <h3>목요일</h3>
    <h3>금요일</h3>
    <h3>토요일</h3>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>