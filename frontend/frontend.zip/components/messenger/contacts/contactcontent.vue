<template>
  <!--Contact Contents start -->
  <div class="contact-sub-content">
    <a
      @click="backtochat()"
      class="icon-btn btn-outline-primary button-effect mobile-back mb-3"
      href="javascript:void(0)"
      ><i class="ti-angle-left"></i
    ></a>
    <div class="row">
      <div class="col-sm-5">
        <div class="user-profile">
          <div class="user-content">
            <img
              class="img-fluid bg-icon"
              src="../../../assets/images/contact/2.jpg"
              alt="user-img"
            />
            <h3>Josephin water</h3>
            <ul>
              <li><i class="fa fa-twitch"></i>message</li>
              <li><i class="fa fa-phone"></i>voice call</li>
              <li><i class="fa fa-video-camera"></i>video call</li>
            </ul>
          </div>
        </div>
        <div class="personal-info-group">
          <div class="social-info-group">
            <ul class="integratin mt-0">
              <li>
                <div class="media">
                  <div class="media-left">
                    <a
                      class="fb"
                      href="https://www.facebook.com/login"
                      target="_blank"
                      ><i class="fa fa-facebook"></i>
                      <h5>Facebook</h5></a
                    >
                  </div>
                  <div class="media-right">
                    <img
                      class="profile"
                      src="../../../assets/images/contact/1.jpg"
                      alt="Avatar"
                    />
                  </div>
                </div>
              </li>
              <li>
                <div class="media">
                  <div class="media-left">
                    <a
                      class="twi"
                      href="https://twitter.com/login"
                      target="_blank"
                      ><i class="fa fa-twitter"></i>
                      <h5>twitter</h5></a
                    >
                  </div>
                  <div class="media-right">
                    <img
                      class="profile"
                      src="../../../assets/images/contact/3.jpg"
                      alt="Avatar"
                    />
                  </div>
                </div>
              </li>
              <li>
                <div class="media">
                  <div class="media-left">
                    <a
                      class="ggl"
                      href="https://accounts.google.com/signin/v2/identifier?service=mail&amp;passive=true&amp;rm=false&amp;continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&amp;ss=1&amp;scc=1&amp;ltmpl=default&amp;ltmplcache=2&amp;emr=1&amp;osid=1&amp;flowName=GlifWebSignIn&amp;flowEntry=ServiceLogin"
                      target="_blank"
                      ><i class="fa fa-google"></i>
                      <h5>google</h5></a
                    >
                  </div>
                  <div class="media-right">
                    <img
                      class="profile"
                      src="../../../assets/images/contact/2.jpg"
                      alt="Avatar"
                    />
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-sm-7">
        <div class="personal-info-group">
          <h3>contact info</h3>
          <ul class="basic-info">
            <li>
              <h5>name</h5>
              <h5 class="details">Nick</h5>
            </li>
            <li>
              <h5>gender</h5>
              <h5 class="details">male</h5>
            </li>
            <li>
              <h5>Birthday</h5>
              <h5 class="details">9 april 1994</h5>
            </li>
            <li>
              <h5>Favorite Book</h5>
              <h5 class="details">Perfect Chemistry</h5>
            </li>
            <li>
              <h5>Personality</h5>
              <h5 class="details">Cool</h5>
            </li>
            <li>
              <h5>City</h5>
              <h5 class="details">Moline Acres</h5>
            </li>
            <li>
              <h5>mobile no</h5>
              <h5 class="details">+0 1800 76855</h5>
            </li>
            <li>
              <h5>email</h5>
              <h5 class="details">pixelstrap@test.com</h5>
            </li>
            <li>
              <h5>Website</h5>
              <h5 class="details">www.test.com</h5>
            </li>
            <li>
              <h5 class="m-0">Interest</h5>
              <h5 class="details">Photography</h5>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!--Contact Contents end -->
</template>

<script>
export default {
  methods: {
    backtochat() {
      document.querySelector(".sidebar-toggle").classList.remove("mobile-menu");
    },
  },
};
</script>
