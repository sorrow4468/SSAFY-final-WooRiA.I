<template>
  <!-- Right-Sidebar Profile's ContactInfo start -->
  <div class="status other">
    <h5 class="block-title p-b-25">Contact info</h5>
    <ul>
      <li>
        <h5>
          <a href="javascript:void(0)">
            <feather type="smartphone" size="15" height="15"></feather>+12
            3456789587</a
          >
        </h5>
      </li>
      <li>
        <h5>
          <a href="https://themeforest.net/user/pixelstrap/portfolio">
            <feather type="crosshair" size="15" height="15"></feather
            >https://pixelstrap</a
          >
        </h5>
      </li>
      <li>
        <h5>
          <a href="javascript:void(0)">
            <feather type="map-pin" size="15" height="15"></feather>1766 Fidler
            Drive Texas, 78238.</a
          >
        </h5>
      </li>
    </ul>
  </div>
  <!-- Right-Sidebar Profile's ContactInfo end -->
</template>
