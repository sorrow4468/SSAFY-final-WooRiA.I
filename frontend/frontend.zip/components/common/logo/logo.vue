<template>
  <!--Logo start -->
  <nuxt-link class="navbar-brand" to="/">
      <div class="logo-block">
        <img
          class="img-fluid"
          src="../../../assets/images/logo/landing-logo.png"
          alt="logo"
        />
      </div>
  </nuxt-link>
  <!--Logo end -->
</template>

