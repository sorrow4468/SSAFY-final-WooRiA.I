<template>
  <!--Footer start -->
  <footer>
    <div class="container footer-main">
      <div class="row footer-block">
        <div class="col-lg-3 col-md-6">
          <div class="footer-title footer-mobile-title">
            <h3>About</h3>
          </div>
          <div class="about-payment footer-contant">
            <div class="logo">
              <nuxt-link to="/messenger/messenger">
                  <img
                    src="../../../assets/images/logo/landing-logo.png"
                    alt="logo"
                />
              </nuxt-link>
            </div>
            <p>
              SSAFY 6기 부울경 2반 6팀 「SIXMAN」
            </p>
          </div>
        </div>
        <div class="col-lg-2 col-md-3">
          <div class="links">
            <div class="footer-title">
              <h3>AI</h3>
            </div>
            <div class="footer-contant">          
              <p class="text-black align-items-center">
                반형동
                <a class="icon-btn btn-google button-effect btn-sm" href="mailto:<아이디>@gmail.com">
                  <i class="fa-brands fa-google"></i>
                </a>
                <a class="icon-btn btn-github button-effect btn-sm" href="https://www.github.com/<깃헙아이디>/">
                  <i class="fa-brands fa-github"></i>
                </a>
              </p>
              <p class="text-black align-items-center">
                손한기
                <a class="icon-btn btn-google button-effect btn-sm" href="onegison95@gmail.com">
                  <i class="fa-brands fa-google"></i>
                </a>
                <a class="icon-btn btn-github button-effect btn-sm" href="https://www.github.com/onegi95/">
                  <i class="fa-brands fa-github"></i>
                </a>
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-3">
          <div class="links">
            <div class="footer-title">
              <h3>Backend</h3>
            </div>
            <div class="footer-contant">
              <p class="text-black align-items-center">
                김영기
                <a class="icon-btn btn-google button-effect btn-sm" href="mailto:<아이디>@gmail.com">
                  <i class="fa-brands fa-google"></i>
                </a>
                <a class="icon-btn btn-github button-effect btn-sm" href="https://www.github.com/<깃헙아이디>/">
                  <i class="fa-brands fa-github"></i>
                </a>
              </p>
              <p class="text-black align-items-center">
                김창민
                <a class="icon-btn btn-google button-effect btn-sm" href="mailto:<아이디>@gmail.com">
                  <i class="fa-brands fa-google"></i>
                </a>
                <a class="icon-btn btn-github button-effect btn-sm" href="https://www.github.com/<깃헙아이디>/">
                  <i class="fa-brands fa-github"></i>
                </a>
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-4">
          <div class="links">
            <div class="footer-title">
              <h3>Frontend</h3>
            </div>
            <div class="footer-contant">
              <p class="text-black align-items-center">
                윤찬호
                <a class="icon-btn btn-google button-effect btn-sm" href="mailto:<아이디>@gmail.com">
                  <i class="fa-brands fa-google"></i>
                </a>
                <a class="icon-btn btn-github button-effect btn-sm" href="https://www.github.com/<깃헙아이디>/">
                  <i class="fa-brands fa-github"></i>
                </a>
              </p>
              <p class="text-black align-items-center">
                이정원
                <a class="icon-btn btn-google button-effect btn-sm" href="mailto:sorrow4468@gmail.com">
                  <i class="fa-brands fa-google"></i>
                </a>
                <a class="icon-btn btn-github button-effect btn-sm" href="https://www.github.com/sorrow4468/">
                  <i class="fa-brands fa-github"></i>
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-back-block">
      <img
        class="img-fluid inner1"
        src="../../../assets/images/landing/footer/2.png"
        alt="footer-back-img"
      /><img
        class="img-fluid inner2"
        src="../../../assets/images/landing/footer/2.png"
        alt="footer-back-img"
      />
    </div>
    <div class="container copyright-footer">
      <!-- <div class="row copyright">
        <div class="col-md-6 col-sm-12">
          <p class="footer-left">© 2021 Chitchat. All Rights Reserved</p>
        </div>
        <div class="col-md-6 col-sm-12 links_horizontal">
          <p class="text-right">
            Made with <span>&hearts; </span>By Theme Pixelstrap
          </p>
        </div>
      </div> -->
    </div>
  </footer>
  <!--Footer end -->
</template>
