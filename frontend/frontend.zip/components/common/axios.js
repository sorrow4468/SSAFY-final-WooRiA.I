import axios from "axios";

let accessToken = localStorage.getItem('jwtToken') || '';
let refreshToken = localStorage.getItem('refreshToken');
// axios 객체 생성
export default axios.create({
  //baseURL: "http://localhost:8080",
  baseURL: "백엔드 주소",
  headers: {
    "Content-type": "application/json",
    "Authorization": accessToken,
    "Refresh" : refreshToken
  },
  withCredentials: true
});
