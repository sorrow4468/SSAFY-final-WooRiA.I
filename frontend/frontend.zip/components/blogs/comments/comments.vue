<template>
  <div class="col-sm-12">
    <div class="blog-commant blog-card">
      <h3>Comments</h3>
      <ul class="comment-section">
        <li>
          <div class="media">
            <img
              src="../../../assets/images/avtar/3.jpg"
              alt="Generic placeholder image"
            />
            <div class="media-body">
              <h6>Josephin water</h6>
              <span
                >( 11 Jannuary 2018 at 1:30AM )
                <a class="pl-2" href="javascript:void(0)">reply</a></span
              >
              <p>
                Donec rhoncus massa quis nibh imperdiet dictum. Vestibulum id
                est sit amet felis fringilla bibendum at at leo. Proin molestie
                ac nisi eu laoreet. Integer faucibus enim nec ullamcorper
                tempor. Aenean nec felis dui. Integer tristique odio mi, in
                volutpat metus posuere eu. Aenean suscipit ipsum nunc, id
                volutpat lorem hendrerit ac. Sed id elit quam. In ac mauris
                arcu.
              </p>
            </div>
          </div>
        </li>
        <li>
          <div class="media">
            <img
              src="../../../assets/images/avtar/1.jpg"
              alt="Generic placeholder image"
            />
            <div class="media-body">
              <h6>Josephin water</h6>
              <span
                >( 12 Jannuary 2018 at 1:30AM )
                <a class="pl-2" href="javascript:void(0)">reply</a></span
              >
              <p>
                Donec rhoncus massa quis nibh imperdiet dictum. Vestibulum id
                est sit amet felis fringilla bibendum at at leo. Proin molestie
                ac nisi eu laoreet. Integer faucibus enim nec ullamcorper
                tempor. Aenean nec felis dui. Integer tristique odio mi, in
                volutpat metus posuere eu. Aenean suscipit ipsum nunc, id
                volutpat lorem hendrerit ac. Sed id elit quam. In ac mauris
                arcu.
              </p>
            </div>
          </div>
        </li>
        <li class="replay">
          <div class="media">
            <img
              src="../../../assets/images/avtar/1.jpg"
              alt="Generic placeholder image"
            />
            <div class="media-body">
              <h6>Josephin water</h6>
              <span
                >( 12 Jannuary 2018 at 1:30AM )
                <a class="pl-2" href="javascript:void(0)">reply</a></span
              >
              <p>
                Donec rhoncus massa quis nibh imperdiet dictum. Vestibulum id
                est sit amet felis fringilla bibendum at at leo. Proin molestie
                ac nisi eu laoreet. Integer faucibus enim nec ullamcorper
                tempor. Aenean nec felis dui. Integer tristique odio mi, in
                volutpat metus posuere eu. Aenean suscipit ipsum nunc, id
                volutpat lorem hendrerit ac. Sed id elit quam. In ac mauris
                arcu.
              </p>
            </div>
          </div>
          <ul>
            <li class="replay">
              <div class="media">
                <img
                  src="../../../assets/images/avtar/1.jpg"
                  alt="Generic placeholder image"
                />
                <div class="media-body">
                  <h6>Josephin water</h6>
                  <span
                    >( 12 Jannuary 2018 at 1:30AM )
                    <a class="pl-2" href="javascript:void(0)">reply</a></span
                  >
                  <p>
                    Donec rhoncus massa quis nibh imperdiet dictum. Vestibulum
                    id est sit amet felis fringilla bibendum at at leo. Proin
                    molestie ac nisi eu laoreet. Integer faucibus enim nec
                    ullamcorper tempor. Aenean nec felis dui. Integer tristique
                    odio mi, in volutpat metus posuere eu. Aenean suscipit ipsum
                    nunc, id volutpat lorem hendrerit ac. Sed id elit quam. In
                    ac mauris arcu.
                  </p>
                </div>
              </div>
            </li>
          </ul>
        </li>
        <li>
          <div class="media">
            <img
              src="../../../assets/images/avtar/3.jpg"
              alt="Generic placeholder image"
            />
            <div class="media-body">
              <h6>Josephin water</h6>
              <span
                >( 11 Jannuary 2018 at 1:30AM )
                <a class="pl-2" href="javascript:void(0)">reply</a></span
              >
              <p>
                Donec rhoncus massa quis nibh imperdiet dictum. Vestibulum id
                est sit amet felis fringilla bibendum at at leo. Proin molestie
                ac nisi eu laoreet. Integer faucibus enim nec ullamcorper
                tempor. Aenean nec felis dui. Integer tristique odio mi, in
                volutpat metus posuere eu. Aenean suscipit ipsum nunc, id
                volutpat lorem hendrerit ac. Sed id elit quam. In ac mauris
                arcu.
              </p>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

