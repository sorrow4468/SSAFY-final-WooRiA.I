<template>
  <div class="col-sm-12">
    <div class="blog-detail blog-card">
      <img
        class="img-fluid"
        src="../../../assets/images/blog/blog-detail.jpg"
        alt=""
      />
      <h2>Also the leap into electronic typesetting unchanged.</h2>
      <div class="post-social">
        <ul>
          <li>25 January 2021</li>
          <li><i class="fa fa-user"></i>Admin</li>
          <li><i class="fa fa-comments"></i> 10 Comment</li>
        </ul>
        <ul class="social-group">
          <li>
            <a class="icon-btn btn-google button-effect btn-sm" href="https://www.facebook.com/"
              ><i class="fa fa-facebook"></i
            ></a>
          </li>
          <li>
            <a class="icon-btn btn-twiter button-effect btn-sm" href="https://twitter.com/"
              ><i class="fa fa-twitter"></i
            ></a>
          </li>
          <li>
            <a class="icon-btn btn-linkedin button-effect btn-sm" href="https://www.linkedin.com/"
              ><i class="fa fa-linkedin"></i
            ></a>
          </li>
          <li>
            <a class="icon-btn btn-instagram button-effect btn-sm" href="https://www.instagram.com/"
              ><i class="fa fa-instagram"></i
            ></a>
          </li>
        </ul>
      </div>
      <p>
        Fusce scelerisque augue a viverra semper. Etiam nisi nibh, vestibulum
        quis augue id, imperdiet fringilla dolor. Nulla sed nisl vel nisi cursus
        finibus. Vivamus ut augue nec justo viverra laoreet. Nunc efficitur,
        arcu ac cursus gravida, lorem elit commodo urna, id viverra libero
        tellus non ipsum. Fusce molestie ultrices nibh feugiat pretium. Donec
        pulvinar arcu metus, et dapibus odio condimentum id. Quisque malesuada
        mauris sit amet dui feugiat, ut pretium mauris luctus. Ut aliquam,
        tellus nec molestie condimentum, tellus arcu dignissim quam, a gravida
        nunc nulla vel magna. Sed pulvinar tortor et euismod blandit. Proin
        accumsan orci ac nunc fermentum vehicula.
      </p>
      <p>
        Cras quis neque urna. Pellentesque mollis, dui nec elementum elementum,
        ipsum quam suscipit ligula, sit amet lobortis dolor sem sed neque.
        Vivamus consequat est non sodales efficitur. Aliquam sodales eleifend
        sodales. Aliquam auctor ipsum quis nisl facilisis, at convallis mauris
        iaculis. Duis eleifend, magna ac convallis blandit, dui dui auctor leo,
        sed tincidunt nisi mauris ut nulla. Praesent porttitor dui ac turpis
        commodo porttitor. Integer ligula nisi, bibendum non sem at, porta
        condimentum dui.
      </p>
      <p>
        Proin id eleifend diam, euismod dictum nibh. Ut ullamcorper in purus at
        tempor. Nullam mattis risus nec velit semper lobortis. Donec accumsan
        ligula fermentum, ultricies massa eget, cursus leo. Suspendisse placerat
        elit et lacus aliquam, ut elementum leo aliquet. Integer ornare, ipsum
        eu lacinia viverra, lectus ipsum scelerisque nisl, nec iaculis leo elit
        id arcu. Aliquam id ante elit. Donec commodo purus eget lacus pharetra,
        et egestas metus blandit. Quisque pellentesque porta urna, sed dictum
        enim viverra a.
      </p>
      <ul class="tags">
        <li><a href="javascript:void(0)">Design</a></li>
        <li><a href="javascript:void(0)">Branding</a></li>
        <li><a href="javascript:void(0)">Clean</a></li>
        <li><a href="javascript:void(0)">CSS3</a></li>
        <li><a href="javascript:void(0)">JQuery</a></li>
      </ul>
    </div>
  </div>
</template>

