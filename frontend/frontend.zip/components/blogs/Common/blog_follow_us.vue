<template>
  <div class="blog-card">
    <h4>follow us</h4>
    <ul class="blog-follow">
      <li><a href="https://www.facebook.com/"><i class="fa fa-facebook-square"></i></a></li>
      <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
      <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
      <li><a href="https://www.skype.com/en/"><i class="fa fa-skype"></i></a></li>
      <li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
    </ul>
  </div>
</template>

