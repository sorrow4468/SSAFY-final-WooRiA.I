<template>
  <div class="blog-card">
    <ul class="tags">
      <li><a href="javascript:void(0)">Design</a></li>
      <li><a href="javascript:void(0)">Clean</a></li>
      <li><a href="javascript:void(0)">CSS3</a></li>
      <li><a href="javascript:void(0)">Portfolio</a></li>
      <li><a href="javascript:void(0)">Pixelstrap</a></li>
      <li><a href="javascript:void(0)">Perfect</a></li>
      <li><a href="javascript:void(0)">NoJquery </a></li>
    </ul>
  </div>
</template>

