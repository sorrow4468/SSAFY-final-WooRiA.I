<template>
  <div class="blog-card">
    <h4>Popular Blog</h4>
    <ul class="popular-blog">
      <li>
        <div class="media">
          <div class="blog-date">
            <h3>03</h3>
            <span>may</span>
          </div>
          <div class="media-body align-self-center">
            <h5>Humour the like</h5>
            <p>
              it look like readable English. Many desktop publishing text.
            </p>
          </div>
        </div>
      </li>
      <li>
        <div class="media">
          <div class="blog-date">
            <h3>03</h3>
            <span>may</span>
          </div>
          <div class="media-body align-self-center">
            <h5>Injected like</h5>
            <p>
              it look like readable English. Many desktop publishing text.
            </p>
          </div>
        </div>
      </li>
      <li>
        <div class="media">
          <div class="blog-date">
            <h3>03</h3>
            <span>may</span>
          </div>
          <div class="media-body align-self-center">
            <h5>Injected like</h5>
            <p>
              it look like readable English. Many desktop publishing text.
            </p>
          </div>
        </div>
      </li>
      <li>
        <div class="media">
          <div class="blog-date">
            <h3>03</h3>
            <span>may</span>
          </div>
          <div class="media-body align-self-center">
            <h5>Injected the</h5>
            <p>
              it look like readable English. Many desktop publishing text.
            </p>
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>

