<template>
  <div class="blog-card">
    <h4>Recent Blog</h4>
    <ul class="recent-blog">
      <li>
        <div class="media">
          <img
            class="img-fluid blur-up lazyload"
            src="../../../assets/images/blog/small/1.jpg"
            alt="Generic placeholder image"
          />
          <div class="media-body align-self-center">
            <h5>1 Dec 2020</h5>
            <p>0 hits</p>
          </div>
        </div>
      </li>
      <li>
        <div class="media">
          <img
            class="img-fluid blur-up lazyload"
            src="../../../assets/images/blog/small/2.jpg"
            alt="Generic placeholder image"
          />
          <div class="media-body align-self-center">
            <h5>2 Dec 2020</h5>
            <p>0 hits</p>
          </div>
        </div>
      </li>
      <li>
        <div class="media">
          <img
            class="img-fluid blur-up lazyload"
            src="../../../assets/images/blog/small/3.jpg"
            alt="Generic placeholder image"
          />
          <div class="media-body align-self-center">
            <h5>3 Dec 2020</h5>
            <p>0 hits</p>
          </div>
        </div>
      </li>
      <li>
        <div class="media">
          <img
            class="img-fluid blur-up lazyload"
            src="../../../assets/images/blog/small/4.jpg"
            alt="Generic placeholder image"
          />
          <div class="media-body align-self-center">
            <h5>4 Dec 2020</h5>
            <p>0 hits</p>
          </div>
        </div>
      </li>
      <li>
        <div class="media">
          <img
            class="img-fluid blur-up lazyload"
            src="../../../assets/images/blog/small/2.jpg"
            alt="Generic placeholder image"
          />
          <div class="media-body align-self-center">
            <h5>5 Dec 2020</h5>
            <p>0 hits</p>
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>

