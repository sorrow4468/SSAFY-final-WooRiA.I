<template>
  <div class="blog-card">
    <h4>search</h4>
    <div class="blog-search">
      <div class="input-group">
        <input
          class="form-control"
          type="text"
          placeholder="search in blog"
        /><span><i class="fa fa-search"></i></span>
      </div>
    </div>
  </div>
</template>

