<template>
  <!-- secure-app start -->
  <section class="section-pb-space secure-app-main">
    <div class="custom-container">
      <div class="row">
        <div class="col-lg-5 offset-lg-7 col-lg-5 offset-lg-2">
          <div class="secure-app-content">
            <div>
              <div class="ply-main">
                <div class="ply-content"><i class="ti-shield"></i></div>
                <h3>Secure Your <span>Messages</span></h3>
              </div>
              <h1>The world's top secure App</h1>
              <h4>
                <span>Desktop App </span>– Easy to use our chat app, Attractive
                and clean design, with many Features :- Dark & light, Recent
                Chat And many more.......
              </h4>
              <nuxt-link to="/messenger/messenger">
                <a class="btn pricing-btn">learn more</a></nuxt-link
              >
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="secure-back-content">
      <img
        class="img-fluid secure-img1"
        src="../../assets/images/landing/parallax/1.png"
        alt="parellex-img1"
      /><img
        class="img-fluid secure-img2"
        src="../../assets/images/landing/parallax/1.png"
        alt="parellex-img1"
      />
    </div>
  </section>
  <!-- secure-app end -->
</template>
