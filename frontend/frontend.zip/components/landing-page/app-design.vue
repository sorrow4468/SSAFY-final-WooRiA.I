<template>
  <!--app  design start -->
  <section class="section-py-space app-design-block" id="features">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="landing-title">
            <div>
              <h1>about app</h1>
            </div>
            <div class="sub-title">
              <div>
                <h4>Exclusive Features</h4>
                <h2>We provide best feature for app design and coding</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row app-code-block">
        <div class="col-md-4">
          <div class="app-design-main">
            <div class="icon-box"><i class="ti-wand"></i></div>
            <img
              class="img-fluid app-hover"
              src="../../assets/images/landing/app/hover.png"
              alt="app hover img"
            />
            <div class="contant-box">
              <h2>latest design</h2>
              <h4>
                Easy to use our chat app, Attractive Features Dark & light.
              </h4>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="app-design-main hover">
            <div class="icon-box"><i class="ti-mobile"></i></div>
            <img
              class="img-fluid app-hover"
              src="../../assets/images/landing/app/hover.png"
              alt="app hover img"
            />
            <div class="contant-box">
              <h2>fully responsive</h2>
              <h4>
                Easy to use our chat app, Attractive Features Dark & light.
              </h4>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="app-design-main">
            <div class="icon-box"><i class="ti-shortcode"></i></div>
            <img
              class="img-fluid app-hover"
              src="../../assets/images/landing/app/hover.png"
              alt="app hover img"
            />
            <div class="contant-box">
              <h2>clean code</h2>
              <h4>
                Easy to use our chat app, Attractive Features Dark & light.
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--app  design end -->
</template>
