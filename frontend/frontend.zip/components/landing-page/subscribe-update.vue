<template>
  <!--subscribe update start -->
  <section class="section-py-space subscribe-main light-bg" id="subscribe">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="landing-title">
            <div>
              <h1>subscribe</h1>
            </div>
            <div class="sub-title">
              <div>
                <h4>Subscribe Newsletter</h4>
                <h2>Subscribe to receive updates</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="custom-container">
      <div class="row subscribe-block">
        <div class="col-md-6">
          <div class="subscribe-content">
            <img
              class="img-fluid"
              src="../../assets/images/landing/subscribe/1.png"
              alt="subscribe-landing"
            />
          </div>
        </div>
        <div class="col-md-6">
          <div class="subscribe-content">
            <div>
              <h1>Subscribe our Newsletter get new update.</h1>
              <form class="form-inline">
                <input class="form-control" placeholder="your name" />
                <input class="form-control" placeholder="email" />
                <button class="btn">Submit</button>
              </form>
              <h4>Check Features. <span><nuxt-link to="/messenger/messenger">Learn More </nuxt-link></span></h4>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="subscribe-back-content">
      <img
        class="img-fluid subscribe-img1"
        src="../../assets/images/landing/subscribe/2.png"
        alt="subscribe-back-img"
      />
    </div>
  </section>
  <!--subscribe update end-->
</template>
