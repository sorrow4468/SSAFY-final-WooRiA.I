<template>
  <!-- team-work start -->
  <section class="section-py-space team-work-main" id="team">
    <div class="custom-container">
      <div class="row team-block">
        <div class="col-md-6">
          <div class="team-work-content">
            <div>
              <div class="ply-main">
                <div class="ply-content">
                  <div class="ply-sub-content"><i class="fa fa-play"></i></div>
                </div>
                <h3>수화닥터는요</h3>
              </div>
              <h1>
                농인분들을 생각하며<br>
                만들었어요
              </h1>
              <h4>
                수화닥터를 통해 농인분들의 병원 진료가<br> 
                조금이라도 더 수월해질 수 있기를 바랍니다
              </h4>
              <nuxt-link class="btn pricing-btn" to="/messenger/messenger">
                팀원 소개 보기</nuxt-link
              >
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="team-work-content">
            <img
              class="img-fluid team-main"
              src="../../assets/images/landing/teamwork/5.png"
              alt="chit-chat"
            />
          </div>
        </div>
      </div>
    </div>
    <img
      class="img-fluid team1"
      src="../../assets/images/landing/teamwork/1.png"
      alt="team-work"
    /><img
      class="img-fluid team2"
      src="../../assets/images/landing/teamwork/2.png"
      alt="team-work"
    /><img
      class="img-fluid team3"
      src="../../assets/images/landing/teamwork/3.png"
      alt="team-work"
    /><img
      class="img-fluid team4"
      src="../../assets/images/landing/teamwork/4.png"
      alt="team-work"
    /><img
      class="img-fluid team5"
      src="../../assets/images/landing/slider/6.png"
      alt="team-work"
    />
  </section>
  <!-- team-work end -->
</template>
