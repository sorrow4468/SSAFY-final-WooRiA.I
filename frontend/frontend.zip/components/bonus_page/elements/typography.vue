<template>
  <section class="header-typography section-pt-space">
    <div class="row">
      <div class="col-12">
        <div class="element-card mt-0">
          <div class="element-card-header heading">
            <h2>H1 to H6 Headings</h2>
          </div>
          <div class="element-card-body typography">
            <h1>This is heading</h1>
            <h2>This is heading</h2>
            <h3>This is heading</h3>
            <h4>This is heading</h4>
            <h5>This is heading</h5>
            <h6>This is heading</h6>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
