<template>
  <client-only>
    <section class="Icons">
        <div class="row">
          <div class="col-12">
            <div class="element-card">
              <div class="element-card-header heading">
                <h2>Icons</h2>
              </div>
              <div class="element-card-body typography">
                <div class="fonts"><a class="icon-btn btn-primary button-effect" href="javascript:void(0)"><feather type="circle" size="13" height="13"></feather></a><a class="icon-btn btn-success button-effect" href="javascript:void(0)"><feather type="users" size="13" height="13"></feather></a><a class="icon-btn btn-danger button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a><a class="icon-btn btn-light button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a><a class="icon-btn btn-warning button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a><a class="icon-btn btn-outline-primary button-effect" href="javascript:void(0)"><feather type="circle" size="13" height="13"></feather></a><a class="icon-btn btn-outline-success button-effect" href="javascript:void(0)"><feather type="users" size="13" height="13"></feather></a><a class="icon-btn btn-outline-danger button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a><a class="icon-btn btn-outline-light button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a><a class="icon-btn btn-outline-warning button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a></div>
              </div>
              <div class="element-card-body typography">
                <div class="fonts">
                  <div class="dot-btn dot-primary"><a class="icon-btn btn-primary button-effect" href="javascript:void(0)"><feather type="circle" size="13" height="13"></feather></a></div>
                  <div class="dot-btn dot-success"><a class="icon-btn btn-success button-effect" href="javascript:void(0)"><feather type="users" size="13" height="13"></feather></a></div>
                  <div class="dot-btn dot-danger"><a class="icon-btn btn-danger button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a></div>
                  <div class="dot-btn dot-light"><a class="icon-btn btn-light button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a></div>
                  <div class="dot-btn dot-warning"><a class="icon-btn btn-warning button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a></div>
                  <div class="dot-btn dot-primary"><a class="icon-btn btn-outline-primary button-effect" href="javascript:void(0)"><feather type="circle" size="13" height="13"></feather></a></div>
                  <div class="dot-btn dot-success"><a class="icon-btn btn-outline-success button-effect" href="javascript:void(0)"><feather type="users" size="13" height="13"></feather></a></div>
                  <div class="dot-btn dot-danger"><a class="icon-btn btn-outline-danger button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a></div>
                  <div class="dot-btn dot-light"><a class="icon-btn btn-outline-light button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a></div>
                  <div class="dot-btn dot-warning"><a class="icon-btn btn-outline-warning button-effect" href="javascript:void(0)"><feather type="star" size="13" height="13"></feather></a></div>
                </div>
              </div>
              <div class="element-card-body typography">
                <div class="fonts"><a class="icon-btn btn-primary button-effect btn-xl" href="javascript:void(0)"><feather type="circle"></feather></a><a class="icon-btn btn-success button-effect btn-xl" href="javascript:void(0)"><feather type="users"></feather></a><a class="icon-btn btn-danger button-effect btn-xl" href="javascript:void(0)"><feather type="star"></feather></a><a class="icon-btn btn-light button-effect btn-xl" href="javascript:void(0)"><feather type="star"></feather></a><a class="icon-btn btn-warning button-effect btn-xl" href="javascript:void(0)"><feather type="star"></feather></a><a class="icon-btn btn-outline-primary button-effect btn-xl" href="javascript:void(0)"><feather type="circle"></feather></a><a class="icon-btn btn-outline-success button-effect btn-xl" href="javascript:void(0)"><feather type="users"></feather></a><a class="icon-btn btn-outline-danger button-effect btn-xl" href="javascript:void(0)"><feather type="star"></feather></a><a class="icon-btn btn-outline-light button-effect btn-xl" href="javascript:void(0)"><feather type="star"></feather></a></div>
              </div>
              <div class="element-card-body typography">
                <div class="fonts"><a class="icon-btn btn-primary button-effect btn-xl rouded15" href="javascript:void(0)"><feather type="circle"></feather></a><a class="icon-btn btn-success button-effect btn-xl rouded15" href="javascript:void(0)"><feather type="users"></feather></a><a class="icon-btn btn-danger button-effect btn-xl rouded15" href="javascript:void(0)"><feather type="star"></feather></a><a class="icon-btn btn-light button-effect btn-xl rouded15" href="javascript:void(0)"><feather type="star"></feather></a><a class="icon-btn btn-warning button-effect btn-xl rouded15" href="javascript:void(0)"><feather type="star"></feather></a><a class="icon-btn btn-outline-primary button-effect btn-xl rouded15" href="javascript:void(0)"><feather type="circle"></feather></a><a class="icon-btn btn-outline-success button-effect btn-xl rouded15" href="javascript:void(0)"><feather type="users"></feather></a><a class="icon-btn btn-outline-danger button-effect btn-xl rouded15" href="javascript:void(0)"><feather type="star"></feather></a><a class="icon-btn btn-outline-light button-effect btn-xl rouded15" href="javascript:void(0)"><feather type="star"></feather></a></div>
              </div>
              <div class="element-card-body typography">
                <div class="fonts">
                  <div class="dot-btn dot-primary grow"><a class="icon-btn btn-primary button-effect" href="javascript:void(0)"><feather type="circle" size="15" height="15"></feather></a></div>
                  <div class="dot-btn dot-success grow"><a class="icon-btn btn-success button-effect" href="javascript:void(0)"><feather type="users" size="15" height="15"></feather></a></div>
                  <div class="dot-btn dot-danger grow"><a class="icon-btn btn-danger button-effect" href="javascript:void(0)"><feather type="star" size="15" height="15"></feather></a></div>
                  <div class="dot-btn dot-light grow"><a class="icon-btn btn-light button-effect" href="javascript:void(0)"><feather type="star" size="15" height="15"></feather></a></div>
                  <div class="dot-btn dot-warning grow"><a class="icon-btn btn-warning button-effect" href="javascript:void(0)"><feather type="star" size="15" height="15"></feather></a></div>
                  <div class="dot-btn dot-primary grow"><a class="icon-btn btn-outline-primary button-effect" href="javascript:void(0)"><feather type="circle" size="15" height="15"></feather></a></div>
                  <div class="dot-btn dot-success grow"><a class="icon-btn btn-outline-success button-effect" href="javascript:void(0)"><feather type="users" size="15" height="15"></feather></a></div>
                  <div class="dot-btn dot-danger grow"><a class="icon-btn btn-outline-danger button-effect" href="javascript:void(0)"><feather type="star" size="15" height="15"></feather></a></div>
                  <div class="dot-btn dot-light grow"><a class="icon-btn btn-outline-light button-effect" href="javascript:void(0)"><feather type="star" size="15" height="15"></feather></a></div>
                  <div class="dot-btn dot-danger grow"><a class="icon-btn btn-outline-light button-effect" href="javascript:void(0)"><feather type="star" size="15" height="15"></feather></a></div>
                </div>
              </div>
              <div class="element-card-body typography">
                <div class="fonts"><a class="icon-btn btn-primary button-effect btn-sm" href="javascript:void(0)"><feather type="circle" size="14" height="14"></feather></a><a class="icon-btn btn-success button-effect btn-sm" href="javascript:void(0)"><feather type="users" size="14" height="14"></feather></a><a class="icon-btn btn-danger button-effect btn-sm" href="javascript:void(0)"><feather type="star" size="14" height="14"></feather></a><a class="icon-btn btn-light button-effect btn-sm" href="javascript:void(0)"><feather type="star" size="14" height="14"></feather></a><a class="icon-btn btn-warning button-effect btn-sm" href="javascript:void(0)"><feather type="star" size="14" height="14"></feather></a><a class="icon-btn btn-outline-primary button-effect btn-sm" href="javascript:void(0)"><feather type="circle" size="14" height="14"></feather></a><a class="icon-btn btn-outline-success button-effect btn-sm" href="javascript:void(0)"><feather type="users" size="14" height="14"></feather></a><a class="icon-btn btn-outline-danger button-effect btn-sm" href="javascript:void(0)"><feather type="star" size="14" height="14"></feather></a><a class="icon-btn btn-outline-light button-effect btn-sm" href="javascript:void(0)"><feather type="star" size="14" height="14"></feather></a><a class="icon-btn btn-outline-warning button-effect btn-sm" href="javascript:void(0)"><feather type="star" size="14" height="14"></feather></a></div>
              </div>
              <div class="element-card-body typography">
                <div class="fonts">
                  <a class="icon-btn btn-primary button-effect btn-xs" href="javascript:void(0)">
                    <feather type="circle" size="13" height="13"></feather>
                    </a>
                    <a class="icon-btn btn-success button-effect btn-xs" href="javascript:void(0)">
                      <feather type="users" size="14" height="14"></feather>
                      </a>
                      <a class="icon-btn btn-danger button-effect btn-xs" href="javascript:void(0)">
                        <feather type="star" size="14" height="14"></feather>
                        </a>
                        <a class="icon-btn btn-light button-effect btn-xs" href="javascript:void(0)">
                          <feather type="star" size="14" height="14"></feather>
                          </a>
                          <a class="icon-btn btn-warning button-effect btn-xs" href="javascript:void(0)">
                            <feather type="star" size="14" height="14"></feather>
                            </a>
                            <a class="icon-btn btn-outline-primary button-effect btn-xs" href="javascript:void(0)">
                              <feather type="circle" size="14" height="14"></feather>
                              </a>
                              <a class="icon-btn btn-outline-success button-effect btn-xs" href="javascript:void(0)">
                                <feather type="users" size="14" height="14"></feather>
                                </a>
                                <a class="icon-btn btn-outline-danger button-effect btn-xs" href="javascript:void(0)">
                                  <feather type="star" size="14" height="14"></feather>
                                  </a>
                                  <a class="icon-btn btn-outline-light button-effect btn-xs" href="javascript:void(0)">
                                    <feather type="star" size="14" height="14"></feather>
                                    </a>
                                    <a class="icon-btn btn-outline-warning button-effect btn-xs" href="javascript:void(0)">
                                      <feather type="star" size="14" height="14"></feather>
                                      </a>
                                      </div>
              </div>
            </div>
          </div>
        </div>
      </section>
  </client-only>
</template>
