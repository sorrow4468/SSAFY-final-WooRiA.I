<template>
  <section class="section-pb-space">
    <div class="row">
      <div class="col-12"></div>
    </div>
  </section>
</template>
