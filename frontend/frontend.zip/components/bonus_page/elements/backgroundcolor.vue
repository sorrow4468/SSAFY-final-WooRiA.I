<template>
  <section class="background">
    <div class="row">
      <div class="col-12">
        <div class="element-card">
          <div class="element-card-header heading">
            <h2>Background Color</h2>
          </div>
          <div class="element-card-body typography">
            <div class="bg-primary p-15">bg-primary</div>
            <div class="bg-success p-15">bg-success</div>
            <div class="bg-danger p-15">bg-danger</div>
            <div class="bg-light p-15">bg-light</div>
            <div class="bg-warning p-15">bg-warning</div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
