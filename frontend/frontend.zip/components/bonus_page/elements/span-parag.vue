<template>
  <section class="element-span-prag">
    <div class="row">
      <div class="col-12">
        <div class="element-card">
          <div class="element-card-header heading">
            <h2>Span and Paragraph</h2>
          </div>
          <div class="element-card-body typography">
            <span class="small_prag">This is span</span>
            <p>
              Lorem Ipsum is simply dummy text printing and typesetting
              industry.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
