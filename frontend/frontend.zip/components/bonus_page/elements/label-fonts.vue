<template>
  <section>
    <div class="row">
      <div class="col-md-6 col-sm-12">
        <div class="element-card">
          <div class="element-card-header heading">
            <h2>Fonts</h2>
          </div>
          <div class="element-card-body typography">
            <div class="badge badge-primary fonts font_label">
              label-primary
            </div>
            <div class="badge badge-success fonts font_label">
              label-success
            </div>
            <div class="badge badge-danger fonts font_label">label-danger</div>
            <div class="badge badge-light fonts font_label">label-light</div>
            <div class="badge badge-warning fonts font_label">
              label-warning
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-sm-12">
        <div class="element-card">
          <div class="element-card-header heading">
            <h2>Fonts</h2>
          </div>
          <div class="element-card-body typography">
            <div class="badge badge-outline-primary fonts font_label">
              label-primary
            </div>
            <div class="badge badge-outline-success fonts font_label">
              label-success
            </div>
            <div class="badge badge-outline-danger fonts font_label">
              label-danger
            </div>
            <div class="badge badge-outline-light fonts font_label">
              label-light
            </div>
            <div class="badge badge-outline-warning fonts font_label">
              label-warning
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
