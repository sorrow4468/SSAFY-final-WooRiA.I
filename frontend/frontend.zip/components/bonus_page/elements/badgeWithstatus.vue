<template>
  <client-only>
    <section>
      <div class="row">
        <div class="col-12">
          <div class="element-card">
            <div class="element-card-header heading">
              <h2>Badge</h2>
            </div>
            <div class="element-card-body typography">
              <div class="dot-btn dot-primary grow font_label">
                <div class="badge badge-outline-primary xl">label-primary</div>
              </div>
              <div class="dot-btn dot-danger grow font_label">
                <div class="badge badge-success xl">label-success</div>
              </div>
              <div class="dot-btn dot-danger font_label">
                <div class="badge badge-outline-primary xl">label-primary</div>
              </div>
              <div class="dot-btn dot-success font_label">
                <div class="badge badge-success xl">label-success</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </client-only>
</template>
