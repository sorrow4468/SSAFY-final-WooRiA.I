<template>
  <section class="element-span-prag">
    <div class="row">
      <div class="col-12">
        <div class="element-card">
          <div class="element-card-header heading">
            <h2>Fonts</h2>
          </div>
          <div class="element-card-body typography">
            <div class="font-primary fonts">font-primary</div>
            <div class="font-success fonts">font-success</div>
            <div class="font-danger fonts">font-danger</div>
            <div class="font-light fonts">font-light</div>
            <div class="font-warning fonts">font-warning</div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
