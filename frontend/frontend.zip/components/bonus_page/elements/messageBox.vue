<template>
  <section class="massage_box">
    <div class="col-12 p-0">
      <div class="element-card element-msg">
        <div class="element-card-header heading">
          <h2>Message Box</h2>
        </div>
        <div class="element-card-body typography">
          <ul class="msg-box fonts">
            <li>
              <h5>Hi Alan, Please send me document.</h5>
            </li>
            <li>
              <h5>Imigiatly.</h5>
            </li>
          </ul>
          <ul class="msg-box fonts">
            <li>
              <h5>Hi Alan, Please send me document.</h5>
            </li>
            <li>
              <h5>Imigiatly.</h5>
            </li>
          </ul>
          <ul class="msg-box fonts">
            <li>
              <h5>Hi Alan, Please send me document.</h5>
            </li>
            <li>
              <h5>Hi Alan, Please .</h5>
            </li>
            <li>
              <h5>Imigiatly.</h5>
            </li>
          </ul>
          <ul class="msg-box fonts">
            <li>
              <h5>Imigiatly.</h5>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>
</template>
