<template>
  <section class="background">
    <div class="row">
      <div class="col-12">
        <div class="element-card element-button">
          <div class="element-card-header heading">
            <h2>Button Background</h2>
          </div>
          <div class="element-card-body typography">
            <a class="btn btn-primary button-effect fonts font_label" href="javascript:void(0)"
              >btn-primary</a
            ><a class="btn btn-success button-effect fonts font_label" href="javascript:void(0)"
              >btn-success</a
            ><a class="btn btn-danger button-effect fonts font_label" href="javascript:void(0)"
              >btn-danger</a
            ><a class="btn btn-light button-effect fonts font_label" href="javascript:void(0)"
              >btn-light</a
            ><a class="btn btn-warning button-effect fonts font_label" href="javascript:void(0)"
              >btn-warning</a
            ><a
              class="btn btn-outline-primary button-effect fonts font_label"
              href="javascript:void(0)"
              >btn-primary</a
            ><a
              class="btn btn-outline-success button-effect fonts font_label"
              href="javascript:void(0)"
              >btn-success</a
            ><a
              class="btn btn-outline-danger button-effect fonts font_label"
              href="javascript:void(0)"
              >btn-danger</a
            ><a
              class="btn btn-outline-light button-effect fonts font_label"
              href="javascript:void(0)"
              >btn-light</a
            ><a
              class="btn btn-outline-warning button-effect fonts font_label"
              href="javascript:void(0)"
              >btn-warning</a
            >
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
