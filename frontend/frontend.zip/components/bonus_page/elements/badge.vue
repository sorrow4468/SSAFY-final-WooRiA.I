<template>
  <client-only>
    <section>
      <div class="row">
        <div class="col-12">
          <div class="element-card">
            <div class="element-card-header heading">
              <h2>Badge</h2>
            </div>
            <div class="element-card-body typography">
              <a class="badge badge-outline-primary font_label" href="javascript:void(0)">
                label-primary</a
              ><a class="badge badge-success font_label" href="javascript:void(0)">
                label-success</a
              >
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 col-sm-12">
          <div class="element-card">
            <div class="element-card-header heading">
              <h2>Badge</h2>
            </div>
            <div class="element-card-body typography">
              <div class="badge badge-outline-primary xl font_label">
                label-primary
              </div>
              <div class="badge badge-success xl font_label">label-success</div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-12">
          <div class="element-card">
            <div class="element-card-header heading">
              <h2>Badge</h2>
            </div>
            <div class="element-card-body typography">
              <div class="badge badge-outline-primary xl rounded font_label">
                label-primary
              </div>
              <div class="badge badge-success xl rounded font_label">
                label-success
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </client-only>
</template>
