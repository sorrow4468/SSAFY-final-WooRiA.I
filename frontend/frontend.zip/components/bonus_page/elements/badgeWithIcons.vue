<template>
  <client-only>
    <section>
      <div class="row">
        <div class="col-12">
          <div class="element-card">
            <div class="element-card-header heading">
              <h2>Badge</h2>
            </div>
            <div class="element-card-body typography">
              <div class="badge badge-outline-primary xl font_label">
                <i class="ti-settings"></i>label-primary
              </div>
              <div class="badge badge-outline-success xl font_label">
                <i class="ti-star"></i>label-success
              </div>
              <div class="badge badge-primary xl font_label">
                <i class="ti-settings"></i>label-primary
              </div>
              <div class="badge badge-success xl font_label">
                <i class="ti-star"></i>label-success
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </client-only>
</template>
