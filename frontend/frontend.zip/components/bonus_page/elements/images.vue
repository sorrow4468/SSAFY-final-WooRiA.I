<template>
  <section>
    <div class="row">
      <div class="col-12">
        <div class="element-card">
          <div class="element-card-header heading">
            <h2>Images</h2>
          </div>
          <div class="element-card-body typography">
            <img
              class="img-10 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            /><img
              class="img-20 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            /><img
              class="img-30 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            /><img
              class="img-40 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            /><img
              class="img-50 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            /><img
              class="img-60 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            /><img
              class="img-70 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            /><img
              class="img-80 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            /><img
              class="img-90 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            /><img
              class="img-100 img-fluid"
              src="../../../assets/images/avtar/1.jpg"
              alt="Avatar"
            />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
