<template>
  <client-only>
    <section>
        <div class="row">
          <div class="col-12">
            <div class="element-card">
              <div class="element-card-header heading">
                <h2>Buttons</h2>
              </div>
              <div class="element-card-body typography"><a class="icon-btn btn-success button-effect btn-xl is-animating font_label" href="javascript:void(0)"><feather type="phone"></feather></a><a class="icon-btn btn-danger button-effect btn-xl is-animating font_label" href="javascript:void(0)"><feather type="phone"></feather></a></div>
            </div>
          </div>
        </div>
    </section>
  </client-only>  
</template>