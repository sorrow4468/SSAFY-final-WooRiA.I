<template>
  <section>
    <div class="row">
      <div class="col-12">
        <div class="element-card">
          <div class="element-card-header heading">
            <h2>Badge</h2>
          </div>
          <div class="element-card-body typography badge-one">
            <div class="badge badge-outline-primary sm font_label">R</div>
            <div class="badge badge-primary sm font_label">E</div>
            <div class="badge badge-outline-success sm font_label">R</div>
            <div class="badge badge-success sm font_label">E</div>
            <div class="badge badge-outline-danger sm font_label">R</div>
            <div class="badge badge-danger sm font_label">E</div>
            <div class="badge badge-outline-warning sm font_label">R</div>
            <div class="badge badge-warning sm font_label">E</div>
            <div class="badge badge-outline-primary sm font_label">R</div>
            <div class="badge badge-info sm font_label">E</div>
            <div class="badge badge-outline-light sm font_label">R</div>
            <div class="badge badge-light sm font_label">E</div>
            <div class="badge badge-outline-dark sm font_label">R</div>
            <div class="badge badge-dark sm font_label">E</div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
