<template>
  <section class="about-page section-py-space">
    <div class="custom-container">
      <div class="row">
        <div class="col-sm-8 offset-sm-2 text-center">
          <Chatting />

          <img
            class="img-fluid w-100 pb-4"
            src="../../../assets/images/about/1.jpg"
            alt="about"
          />
          <div class="row">
            <div class="col-md-10 offset-md-1">
              <p>
                On the other hand, we denounce with righteous indignation and
                dislike men who are so beguiled and demoralized by the charms of
                pleasure of the moment, so blinded by desire, that they cannot
                foresee the pain and trouble that are bound to ensue; and equal
                blame belongs to those who fail in their duty through weakness
                of will, which is the same as saying through shrinking from toil
                and pain. These cases are perfectly simple and easy to
                distinguish.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import Chatting from "./Chatting.vue";

export default {
  name: "about-page",

  components: {
    Chatting,
  },
};
</script>
