<template>
  <section class="error-main">
    <ul class="page-decore">
      <li class="top">
        <img
          class="img-fluid inner2"
          src="../../assets/images/landing/footer/2.png"
          alt="footer-back-img"
        />
      </li>
      <li class="bottom">
        <img
          class="img-fluid inner2"
          src="../../assets/images/landing/footer/2.png"
          alt="footer-back-img"
        />
      </li>
    </ul>
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="error-contain">
            <h1>404</h1>
            <h2>Page Not Found</h2>
            <h4>
              The Page You Are Attempting To Reach Is Not Available. <br />This
              May Be Because The Page Does Not Exist Or Has Been Moved.
            </h4>
            <nuxt-link to="/">
              <a class="btn btn-primary">back to home</a>
            </nuxt-link>
            <div class="animated-bg"><i></i><i></i><i></i></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

